import warnings
warnings.filterwarnings('ignore')
seed_value= 42
import os
os.environ['PYTHONHASHSEED']=str(seed_value)
import random
random.seed(seed_value)
import numpy as np
np.random.seed(seed_value)
from datetime import timedelta, datetime
import math
from dateutil import parser
from binance.client import Client
import calendar
import pandas as pd
from sklearn.preprocessing import MinMaxScaler

def featurebylewis(ddf_pd2):
    ddf_pd2['p']=0
    p=0
    sk=10
    for i in range(sk,len(ddf_pd2['p'])):
        if i%24==0:
            p=0
        if ddf_pd2['open'][i-sk]<ddf_pd2['close'][i]:
            p=p+10
            ddf_pd2['p'][i]=p
        else:
            p=p-10
            ddf_pd2['p'][i]=p
    ddf_pd2=ddf_pd2[::-1]
    ddf_pd2=FeatureEngineringbtc(ddf_pd2)
    ddf_pd2=ddf_pd2[::-1]
    ddf_pd2=ddf_pd2[288:]
    y=np.zeros((len(ddf_pd2)-10, 1))
    for i in range(len(ddf_pd2)-10):
        y[i]=ddf_pd2['p'][i+10]
    del ddf_pd2['p']
    return ddf_pd2,y

def relative_strength(prices, n=9):

    deltas = np.diff(prices)
    seed = deltas[:n+1]
    up = seed[seed >= 0].sum()/n
    down = -seed[seed < 0].sum()/n
    rs = up/down
    rsi = np.zeros_like(prices)
    rsi[:n] = 100. - 100./(1. + rs)

    for i in range(n, len(prices)):
        delta = deltas[i - 1]  # cause the diff is 1 shorter

        if delta > 0:
            upval = delta
            downval = 0.
        else:
            upval = 0.
            downval = -delta

        up = (up*(n - 1) + upval)/n
        down = (down*(n - 1) + downval)/n

        rs = up/down
        rsi[i] = 100. - 100./(1. + rs)

    return rsi
def moving_average(x, n, type='simple'):

    x = np.asarray(x)
    if type == 'simple':
        weights = np.ones(n)
    else:
        weights = np.exp(np.linspace(-1., 0., n))

    weights /= weights.sum()

    a = np.convolve(x, weights, mode='full')[:len(x)]
    a[:n] = a[n]
    return a
def moving_average_convergence(x, nslow=26, nfast=12):
    
    emaslow = moving_average(x, nslow, type='exponential')
    emafast = moving_average(x, nfast, type='exponential')
    return emaslow, emafast, emafast - emaslow

def FeatureEngineringbtc(MyRawData):
    MyRawData['BodyPips'] = abs((MyRawData['open']-MyRawData['close']) * 10000)
    MyRawData['WickUpPips'] = (abs(MyRawData['open']-MyRawData['high']) * 10000)
    MyRawData['WickDownPips'] = (abs(MyRawData['close']-MyRawData['low']) * 10000)
    MyRawData['type'] = 0
    MyRawData.loc[MyRawData['close'] > MyRawData['open'] , 'type'] = 1
    MyRawData['EmaSlow'], MyRawData['EmaFast'], MyRawData['MACD'] = moving_average_convergence(MyRawData['close'].values, nslow=9, nfast=4)                   
    MyRawData['Ema9'] = moving_average(MyRawData['MACD'].values, 9, type='exponential')
    MyRawData['RSI'] = relative_strength(MyRawData['close'].values) 
    MyRawData=MyRawData[::-1]
    MyRawData['Rolling Mean'] = MyRawData['close'].rolling(window=7).mean()
    MyRawData['Bollinger High'] = MyRawData['close'].rolling(window=7).mean() + (MyRawData['close'].rolling(window=7).std() * 2)
    MyRawData['Bollinger Low'] = MyRawData['close'].rolling(window=7).mean() - (MyRawData['close'].rolling(window=7).std() * 2)
    MyRawData=MyRawData[::-1]
    for CandleCount in range(10):
        ActualCandleCount = CandleCount + 1
        MyRawData['BodyPips' + '_' + str(ActualCandleCount)] = MyRawData['BodyPips'].shift(-ActualCandleCount)
        MyRawData['WickUpPips' + '_' + str(ActualCandleCount)] = MyRawData['WickUpPips'].shift(-ActualCandleCount)
        MyRawData['WickDownPips' + '_' + str(ActualCandleCount)] = MyRawData['WickDownPips'].shift(-ActualCandleCount)
        MyRawData['type' + '_' + str(ActualCandleCount)] = MyRawData['type'].shift(-ActualCandleCount)
        MyRawData['EmaSlow' + '_' + str(ActualCandleCount)] = MyRawData['EmaSlow'].shift(-ActualCandleCount)
        MyRawData['EmaFast' + '_' + str(ActualCandleCount)] = MyRawData['EmaFast'].shift(-ActualCandleCount)
        MyRawData['MACD' + '_' + str(ActualCandleCount)] = MyRawData['MACD'].shift(-ActualCandleCount)
        MyRawData['Ema9' + '_' + str(ActualCandleCount)] = MyRawData['Ema9'].shift(-ActualCandleCount)
        MyRawData['RSI' + '_' + str(ActualCandleCount)] = MyRawData['RSI'].shift(-ActualCandleCount)
        MyRawData['Rolling Mean' + '_' + str(ActualCandleCount)] = MyRawData['Rolling Mean'].shift(-ActualCandleCount)
        MyRawData['Bollinger High' + '_' + str(ActualCandleCount)] = MyRawData['Bollinger High'].shift(-ActualCandleCount)
        MyRawData['Bollinger Low' + '_' + str(ActualCandleCount)] = MyRawData['Bollinger Low'].shift(-ActualCandleCount)
        
    return MyRawData