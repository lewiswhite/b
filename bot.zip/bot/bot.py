import warnings
warnings.filterwarnings('ignore')
seed_value= 42
import os
os.environ['PYTHONHASHSEED']=str(seed_value)
import random
random.seed(seed_value)
import numpy as np
np.random.seed(seed_value)
from datetime import timedelta, datetime
import math
from dateutil import parser
from binance.client import Client
import calendar
from sklearn.preprocessing import MinMaxScaler
import time
from csv import writer
import Algorithmia
            
import lewisfeature as lf

model = load_model('pVALmodel.hdf5')
scaler = MinMaxScaler(feature_range=(0, 1))
scalery = MinMaxScaler(feature_range=(0, 1))
binance_api_key = 'PGwbdkXYToBUnwMqWVg4iA9lnIlZ2KWcTIwdiGZLyJL14pb0N3M5txyU6BN5GdQe'    
binance_api_secret = '5V3X0NiFK5SO9rvN6ZW0kvgcqAaD2ry7MXqvEc9FJbJnvwsBfsvhabifz4bM0vzi' 
binsizes = {"1m": 1, "5m": 5, "1h": 60, "1d": 1440}
binance_client = Client(api_key=binance_api_key, api_secret=binance_api_secret)

def minutes_of_new_data(symbol, kline_size, data,periodd, source):
	getperiod=periodd
	if len(data) > 0:  old = parser.parse(data["timestamp"].iloc[-1])
	elif source == "binance": old = datetime.strptime(getperiod, '%d %b %Y')
	if source == "binance": new = pd.to_datetime(binance_client.get_klines(symbol=symbol, interval=kline_size)[-1][0], unit='ms')
	return old, new

def get_all_binance(symbol, kline_size,period, save = False):
    neww=0
    getperiod=period
    filename = '%s-%s-data.csv' % (symbol, kline_size)
    if os.path.isfile(filename): data_df = pd.read_csv(filename)
    else: data_df = pd.DataFrame()
    oldest_point, newest_point = minutes_of_new_data(symbol, kline_size, data_df, getperiod, source = "binance")
    delta_min = (newest_point - oldest_point).total_seconds()/60
    available_data = math.ceil(delta_min/binsizes[kline_size])
    if oldest_point == datetime.strptime(period, '%d %b %Y'):
        print('Downloading all available %s data for %s. Be patient..!' % (kline_size, symbol))
        neww=0
    else:
        if available_data > 0:
            neww=1
            print('Downloading %d minutes of new data available for %s, i.e. %d instances of %s data.' % (delta_min, symbol, available_data, kline_size))
    klines = binance_client.get_historical_klines(symbol, kline_size, oldest_point.strftime("%d %b %Y %H:%M:%S"), newest_point.strftime("%d %b %Y %H:%M:%S"))
    data = pd.DataFrame(klines, columns = ['timestamp', 'open', 'high', 'low', 'close', 'volume', 'close_time', 'quote_av', 'trades', 'tb_base_av', 'tb_quote_av', 'ignore' ])
    data['timestamp'] = pd.to_datetime(data['timestamp'], unit='ms')
    if len(data_df) > 0:
        temp_df = pd.DataFrame(data)
        data_df = data_df.append(temp_df)
    else: data_df = data
    data_df.set_index('timestamp', inplace=True)
    if save: data_df.to_csv(filename)
    print('Bot is Runing All caught up..!')
    return neww
# create a buy order
def buy(pair,quant):
    buy_limit = binance_client.create_order(
        symbol=pair,
        side=Client.SIDE_BUY,
        type=Client.ORDER_TYPE_MARKET,
        quantity=quant
        )
    return buy_limit
# create a sell order
def sell(pair,quant):
    sell_limit = binance_client.create_order(
        symbol=pair,
        side=Client.SIDE_SELL,
        type=Client.ORDER_TYPE_MARKET,
        quantity=quant
        )
    return sell_limit

pair="MATIC"

trades=binance_client.get_all_orders(symbol=pair+'USDT',limit=25)
for i in range(0,len(trades)):
    if trades[i]['side']=="BUY":
        with open("trades_id.csv", 'a', newline='') as fp:
            csv_writer = writer(fp)
            ssll=[]
            ssll.append(trades[i]['orderId'])
            csv_writer.writerow(ssll)

def check_decimals(symbol):
    info = binance_client.get_symbol_info(symbol)
    val = info['filters'][2]['stepSize']
    decimal = 0
    is_dec = False
    for c in val:
        if is_dec is True:
            decimal += 1
        if c == '1':
            break
        if c == '.':
            is_dec = True
    return decimal


client = Algorithmia.client("sim2s/kudBLEs/PL3QGA1mI0V+s1")
            
algo = client.algo('Dolus/BinBot/8.0.0')

play=round(11)

while 1:
  new=get_all_binance(pair+'USDT', "5m",'15 MAY 2021', save = True)
  ddf_pd2 = pd.read_csv(pair+'USDT-5m-data.csv')
  ddf_pd2=ddf_pd2.drop_duplicates(subset=['timestamp'], keep='last',ignore_index=True)
  ddf_pd2=ddf_pd2[:-1]
  ddf_pd2['Date']=ddf_pd2['timestamp']
  ddf_pd2=ddf_pd2.set_index('Date')
  del ddf_pd2['close_time']
  del ddf_pd2['tb_base_av']
  del ddf_pd2['tb_quote_av']
  del ddf_pd2['ignore']
  del ddf_pd2['timestamp']
  del ddf_pd2['quote_av']
  del ddf_pd2['trades']
  if new==1:
    X,y=lf.featurebylewis(ddf_pd2)
    X1 = scaler.fit_transform(X)
    y = scalery.fit_transform(y.reshape(-1, 1))
    #z=len(X)-17
    #while z in range(len(X)-17,len(X)):
        #Xx = X[z-k:z]
        #l=scaler.fit_transform(Xx)
        #X1[z-1] = l[-1]
        #z=z+1
    Xx = X[-8064:]
    l=scaler.fit_transform(Xx)
    X1[-1] = l[-1]
    X = np.reshape(X1, (len(X1),137,1))
    X = np.asarray(X).astype(np.float64)
    y = np.asarray(y).astype(np.float64)
    strx=""
    for i in range (137):
        strx=strx+str(X[-1:][0][i][0])+","
    strx = strx.rstrip(strx[-1])
    pred2 = np.zeros((1,1), dtype=np.float32)
    pred2[0][0]=float(algo.pipe(strx).result)
    #pred2=model.predict(X[-1:])#model.predict(X[-17:])
    pred2 = scalery.inverse_transform(pred2)
    y = scalery.inverse_transform(y)
    #window_size = 7
    #i = 0
    #pred_averages1 = []
    #while i < len(pred2) - window_size + 1:
    #    this_window = pred2[i : i + window_size]
    #    window_average = (sum(this_window) / window_size)
    #    pred_averages1.append(window_average)
    #    i=i+1
    #for i in range(len(pred_averages1)):
    #  pred_averages1[i]=round(pred_averages1[i][0])
      
    if y[-1]<pred2[-1] and pred2[-1]>0:#pred_averages1[-11]<pred_averages1[-1] and pred_averages1[-1]>0:
      balance=binance_client.get_asset_balance(asset='USDT')
      current_usdt_price=binance_client.get_symbol_ticker(symbol=pair+'USDT')
      quant=(play)/float(current_usdt_price['price'])
      buy_limit=buy(pair+'USDT',round(quant,check_decimals(pair+"USDT")))
    else:
    trades=binance_client.get_all_orders(symbol=pair+'USDT',limit=25)
    for i in range(0,len(trades)):
        if trades[i]['side']=="BUY":
            trade_id=pd.read_csv("trades_id.csv")
            chk=trade_id[trade_id['id'].isin([trades[i]['orderId']])]
            if chk.empty==True:
              ts = time.time()
              if (round(ts*1000)>=trades[i]['time']+3600000) :
                  sell_limit=sell(pair+'USDT',trades[i]['origQty'])
                  with open("trades_id.csv", 'a', newline='') as fp:
                      csv_writer = writer(fp)
                      ssll=[]
                      ssll.append(trades[i]['orderId'])
                      csv_writer.writerow(ssll)
              
    time.sleep(200)

    